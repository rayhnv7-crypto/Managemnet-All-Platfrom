# Management-clipper-hub

Source bundle for CLIPPER HUB personal management interface and Node.js OAuth/API gateway.

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Generate a 32-byte encryption key with:
   `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
4. Put the generated value in `TOKEN_ENCRYPTION_KEY` in `.env`.
5. Add official provider credentials to `.env` only when available.
6. Run `npm start` and open `http://localhost:3000`.

## Important status and limitations

- The app serves its frontend and API from the same Node.js process.
- The gateway currently has health, provider, connection, logs, and OAuth start/callback routes for TikTok, Meta, Google, LinkedIn, and X.
- Provider credentials are read from server environment variables. The current UI does not provide a complete secure server-side Client ID/Client Secret save form; do not enter provider secrets into browser fields.
- OAuth is not active until the relevant developer app is approved/configured, redirect URIs and scopes match the provider console, and environment variables are set.
- This bundle is a Node.js server app, not yet a Vercel serverless conversion. Do not connect it to a Vercel project with a static-only output configuration and assume OAuth will work.
- Publishing, Ads execution, Inbox, and analytics data sync are not implemented as live integrations in this bundle.

## Security

Never commit `.env`, API keys, client secrets, access tokens, or `data/store.json`. Keep secrets in the deployment platform's encrypted environment variables.
